/*
 * File:    nooutput.c 
 * Purpose: exits with no output
 * Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
 *
 * $Id: hello.c 1631 2008-11-05 03:03:12Z laned $
 *
 */

#include <stdio.h>

int main (int argc, char **argv)
{
        
        return(0);
}

/* eof */
