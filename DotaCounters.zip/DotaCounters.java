import static java.lang.System.*;
import java.net.*;
import java.util.*;

public class DotaCounters
{
	public static void main(String args[])throws Throwable
	{
		TreeMap<String, HashSet<String>> all = new TreeMap<String, HashSet<String>>();
		TreeMap<String, Integer> map = new TreeMap<String, Integer>();
		Scanner kb = new Scanner(in);
		while(true)
		{
			String in = kb.nextLine();
			switch(in.split(" ")[0].toLowerCase())
			{
				case "run":
					out.println("Counters: ");
					for(String a:all.keySet())
					{
						for(String b: all.get(a))
						{
							if(map.get(b)==null)
								map.put(b, 0);
							map.put(b, map.get(b)+1);
						}

					}
					for(int z=all.size(); z>0; z--)
						for(String a:map.keySet())
							if(map.get(a)==z && !all.containsKey(a))
								out.println(z+": "+a);
					map.clear(); break;
				case "clear": all.clear();out.println("List Cleared!"); break;
				case "items": getItems("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "stats": getStats("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "build": getBuild("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "time": getTimes("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "bv": getBestVS("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "wv": getWorstVS("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "vs": getMatchup(in.split(" ")[1], in.split(" ")[2]); break;
				case "best": getBest("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "roles": getRoles("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "winrate": getWinrate("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "popularity": getPopularity("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "lanes": getLane("http://www.dotabuff.com/heroes/"+in.split(" ")[1]); break;
				case "help": getHelp(); break;
				case "remove": all.remove(in.split(" ")[1]);out.println(in.split(" ")[1]+" removed!"); break;
				case "add": HashSet<String> set = getCounters("http://www.dotabuff.com/heroes/"+in.split(" ")[1]);
							if(set==null) break;
							all.put(in.split(" ")[1], set);out.println(in.split(" ")[1]+" added!"); break;
				default: out.println("WTF you trying to say?");break;

			}
			out.println();
		}
	}

	public static void getHelp()
	{
		out.println("\nInput should always be in the form <command> <parameter(s)>\nList of all known commands: (all commands are case insensitive)\n---------------------------------------------------------------------------------------------------------");
		out.println("Add:        Adds a hero to the list of heros to be countered.");
		out.println("Remove:     Removes a hero from that list.");
		out.println("Clear:      Clears all heros from the list.");
		out.println("Run:        Prints a list of heros in decending order by the number of times they counter a hero in the list.");
		out.println("Items:      Print out the list of most popular items for the given hero this week.");
		out.println("Stats:      Prints out the stats given hero such as attribute gain, movement speed, sight range.");
		out.println("Build:      Prints the most popular skill for the given hero.");
		out.println("Time:       Prints out the hero's total time played this month and all time.");
		out.println("BV:         Prints a list of heros that the given hero is best versus.");
		out.println("WV:         Prints a list of heros that the given hero is worst versus.");
		out.println("VS:         Given two heroes prints out stats about the matchup of the first vs the second.");
		out.println("Best:       Prints the top players on the given hero according to Dotabuff.");
		out.println("Roles:      Prints the roles the hero is most suited to play");
		out.println("Winrate:    Prints the winrate of the hero.");
		out.println("Popularity: Prints the hero's popularity this week as a rank.");
		out.println("Lanes:      Prints various stats about a hero's preformance in a particular lane.");
		out.println("Help:       Prints this help page.");
		out.println("---------------------------------------------------------------------------------------------------------");
		out.println("");
		out.println("");
	}
	public static Scanner getSite(String site)throws Throwable
	{
		URL url = new URL(site);
	    HttpURLConnection con = (HttpURLConnection) url.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.125 Safari/537.36");
		Scanner file = null;
		try
		{
		    file = new Scanner(con.getInputStream());
		}
		catch(Exception e)
		{
			out.println("Invalid Hero Name (lol noob)");
		}
	    return file;
	}

	public static String getSiteString(String site)throws Throwable
	{
		URL url = new URL(site);
	    HttpURLConnection con = (HttpURLConnection) url.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.125 Safari/537.36");
		Scanner file = null;
		try
		{
		    file = new Scanner(con.getInputStream());
		}
		catch(Exception e)
		{
			out.println("Invalid Hero Name (lol noob)");
		}
		if(file == null)
			return null;
		file.nextLine();
		file.nextLine();
		String line = file.nextLine();
	    return line;
	}

	public static void getBuild(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("skill-choices smaller"));
		out.println("_________________________________________________________");
		for(int z = 0; z<5; z++)
		{
			out.print("|"+(z==0?"Q":z==1?"W":z==2?"E":z==3?"R":"+")+"|");
			for(int y = 1; y<=18; y++)
			{
				if(line.indexOf("entry choice")>line.indexOf("entry empty") && line.indexOf("entry empty")!=-1 && line.indexOf("entry choice")!=-1 || line.indexOf("entry choice")==-1)
				{
					out.print("..|");
					line = line.substring(line.indexOf("entry empty")+2);
				}
				else
				{
					out.printf("%2d|", y);
					line = line.substring(line.indexOf("entry choice")+2);
				}
			}
			out.println("");
		}
		out.println();
	}

	public static HashSet<String> getCounters(String site)throws Throwable
	{
		HashSet<String> temp = new HashSet<String>();
		String line = getSiteString(site);
		if(line==null)
			return null;
		line = line.substring(line.indexOf("Worst Versus"));
		while(line.contains("data-link-to=\""))
		{
			String t = line.substring(line.indexOf("data-link-to=\"")+30, line.indexOf("\"", line.indexOf("data-link-to=\"")+15));
			if(!t.matches(".*\\d.*"))
				temp.add(t);
			line= line.substring(line.indexOf("\"", line.indexOf("data-link-to=\"")+1));
		}
		return temp;
	}

	public static void getBestVS(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Best Versus"));
		for(int z = 1; z<=8; z++)
		{
			String t = line.substring(line.indexOf("data-link-to=\"")+30, line.indexOf("\"", line.indexOf("data-link-to=\"")+15));
			if(!t.matches(".*\\d.*"))
				out.println(z+": "+t);
			line= line.substring(line.indexOf("\"", line.indexOf("data-link-to=\"")+1));
		}
	}

	public static void getWorstVS(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Worst Versus"));
		for(int z = 1; z<=8; z++)
		{
			String t = line.substring(line.indexOf("data-link-to=\"")+30, line.indexOf("\"", line.indexOf("data-link-to=\"")+15));
			if(!t.matches(".*\\d.*"))
				out.println(z+": "+t);
			line= line.substring(line.indexOf("\"", line.indexOf("data-link-to=\"")+1));
		}
	}

	public static void getBest(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Hero Rankings"));
		for(int z = 1; z<=8; z++)
		{
			String t = line.substring(line.indexOf("img alt=\"")+9, line.indexOf("\"", line.indexOf("img alt=\"")+9));
			for(int y = 32; y<128; y++)
				t = t.replace("&#"+y+";", ""+(char)y);
			out.println(z+": "+t);
			line= line.substring(line.indexOf("\"", line.indexOf("img alt=\"")+1));
		}
	}

	public static void getStats(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Hero Attributes"));
		String primary = line.substring(line.indexOf("<tbody class=\"primary-")+22, line.indexOf("\"", line.indexOf("<tbody class=\"")+14));
		out.println("Primary Attribute: "+Character.toUpperCase(primary.charAt(0))+primary.substring(1));
		for(int z = 1; z<=9; z++)
		{
			String t = line.substring(line.indexOf("<td>")+4, line.indexOf("<", line.indexOf("<td>")+4));
			if(z>3)
			{
				t+=":";
				line= line.substring(line.indexOf("<", line.indexOf("<td>")+4));
				String p = line.substring(line.indexOf("<td>")+4, line.indexOf("<", line.indexOf("<td>")+4)).replace("&#47;", "/");
				out.printf("%-18s %s%n",t,p);
			}
			else
				out.println((z==1?"Strength:          ":z==2?"Agility:           ":z==3?"Intelligence:      ":"")+t);
			line= line.substring(line.indexOf("<", line.indexOf("<td>")+4));
		}
	}

	public static void getTimes(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Time Played"));
		for(int z = 1; z<=2; z++)
		{
			String t = line.substring(line.indexOf("<td>")+4, line.indexOf("<", line.indexOf("<td>")+4));
			line= line.substring(line.indexOf("<", line.indexOf("<td>")+4));
			String p = line.substring(line.indexOf("<td>")+4, line.indexOf("<", line.indexOf("<td>")+4)).replace("&#47;", "/");
			line= line.substring(line.indexOf("<", line.indexOf("<td>")+4));
			out.println(t+": "+p);
		}
	}

	public static void getItems(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Most Used Items"));
		for(int z = 1; z<=12; z++)
		{
			String t = line.substring(line.indexOf("data-link-to=\"")+29, line.indexOf("\"", line.indexOf("data-link-to=\"")+15));
			out.println(z+": "+t);
			line= line.substring(line.indexOf("\"", line.indexOf("data-link-to=\"")+1));
		}
	}

	public static void getRoles(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("header-content-title"));
		String t = line.substring(line.indexOf("<small>")+7, line.indexOf("</small>"));
		out.println("Roles: "+t);
	}

	public static void getWinrate(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("header-content-secondary")+25);
		String t = line.substring(line.indexOf("\">")+2, line.indexOf("</span>"));
		out.println("Win Rate: "+t);
	}

	public static void getPopularity(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("header-content-secondary"));
		String t = line.substring(line.indexOf("<dd>")+4, line.indexOf("</dd>"));
		out.println("Popularity: "+t);
	}

	public static void getLane(String site)throws Throwable
	{
		String line = getSiteString(site);
		if(line==null)
			return;
		line = line.substring(line.indexOf("Lane Presence"));
		line = line.substring(line.indexOf("article"), line.indexOf("/article"));
		line = line.substring(line.indexOf("/tr")+5);
		out.println("Lane Presence:");
		out.println("  Lane           Presence   Win Rate   KDA Ratio    GPM       XPM");
		while(line.contains("tr>"))
		{
			String[] values = new String[6];
			values[0] = line.substring(line.indexOf("<td>")+4, line.indexOf("<", line.indexOf("<td>")+4));
			line = line.substring(line.indexOf("</td>")+5);
			for(int z = 1; z<6; z++)
			{
				values[z] = line.substring(line.indexOf("data-value=\"")+12, line.indexOf("\"", line.indexOf("data-value=\"")+13));
				line = line.substring(line.indexOf("</td>")+5);
			}
			line = line.substring(line.indexOf("</tr>")+5);
			out.printf("%-14s%9.02f%%%10.02f%%%10.02f%12.02f%10.02f\n", values[0], Double.parseDouble(values[1]), Double.parseDouble(values[2]), Double.parseDouble(values[3]), Double.parseDouble(values[4]), Double.parseDouble(values[5]));
		}
	}

	public static void getMatchup(String hero1, String hero2)throws Throwable
	{
		Scanner file = getSite("http://www.dotabuff.com/heroes/"+hero1+"/matchups");
		if(file==null)
			return;
		String qe = file.nextLine();
		String heroname = qe.substring(qe.indexOf("title>")+6, qe.indexOf("<", qe.indexOf("title>")+6)).split("-")[0].trim();
		file.nextLine();file.nextLine();file.nextLine();file.nextLine();file.nextLine();file.nextLine();file.nextLine();file.nextLine();
		String[] values = new String[4];
		String line = file.nextLine();
		try
		{
			line = line.substring(line.indexOf(hero2));
		}
		catch(Exception e)
		{
			out.println("Invalid Hero Name (lol noob)");
			return;
		}
		values[0] = line.substring(line.indexOf("data-value=\"")+12, line.indexOf("\"", line.indexOf("data-value=\"")+13));
		if(values[0].matches(".*\\d.*"))
		{
			out.println("Invalid Hero Name (lol noob)");
			return;
		}
		line = line.substring(line.indexOf("/td")+5);
		line = line.substring(line.indexOf("/td")+5);
		out.printf("\n%"+((values[0].length()-4)/2+3)+"s%"+(values[0].length()-((values[0].length()-4)/2)+10)+"s%"+(heroname.length()+13)+"s%18s\n", "Hero", "Advantage", heroname+" Win Rate", "Matches Played");
		for(int z = 1; z<4; z++)
		{
			values[z] = line.substring(line.indexOf("data-value=\"")+12, line.indexOf("\"", line.indexOf("data-value=\"")+13));
			line = line.substring(line.indexOf("</td>")+5);
		}
		out.printf("%s%11.02f%"+(heroname.length()+10)+".02f%%%"+(values[3].length()+12)+"s\n", values[0], Double.parseDouble(values[1]), Double.parseDouble(values[2]), values[3]);
	}

}